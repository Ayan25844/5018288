import java.util.HashMap;

public class inventory extends product {

    private String productId;
    private static HashMap<String, product> map = new HashMap<>();

    public inventory(String id, String name, int quantity, double price) {
        super(name, quantity, price);
        this.productId = id;
    }

    private static void print() {
        System.out.println("{");
        for (String i : map.keySet()) {
            System.out.println(
                    " { " + i + " : " + map.get(i).getName() + " , " + map.get(i).getQuantity() + " , "
                            + map.get(i).getPrice()
                            +
                            " } ");
        }
        System.out.println("}");
        System.out.println();
    }

    public void add() {
        if (map.containsKey(this.productId)) {
            System.out.println(
                    "Product cannot be added because it is already present in the cart. Please update your cart.");
        } else {
            map.put(this.productId, this);
            System.out.print("Cart items: ");
            print();
        }
    }

    public void update(String newName, int newQuantity, double newPrice) {
        if (!map.containsKey(this.productId)) {
            System.out.println(
                    "Product details cannot be updated because the product is not in the cart. Please add to cart.");
        } else {
            super.setName(newName);
            super.setPrice(newPrice);
            super.setQuantity(newQuantity);
            print();
        }
    }

    public void delete() {
        if (!map.containsKey(this.productId)) {
            System.out
                    .println("Product cannot be deleted because it is not present in your cart.\n Please add to cart.");
        } else {
            map.remove(this.productId);
            System.out.print("Cart items: ");
            print();
        }
    }
}