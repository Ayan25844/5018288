import java.util.Scanner;
import java.util.ArrayList;

public class Main {

    private static ArrayList<inventory> list = new ArrayList<>();

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.print(
                    "Do you want to select a product ? (Enter 'yes', or 'no' to quit): ");
            String action = input.next();

            switch (action.toLowerCase()) {
                case "yes":
                    selectProduct(input);
                    break;

                case "no":
                    input.close();
                    System.out.println("Exiting the program.");
                    return;

                default:
                    System.out.println("Invalid action. Please enter 'create', 'view', or 'exit'.");
                    break;
            }
        }
    }

    private static void selectProduct(Scanner input) {

        System.out.print("Select your product id: ");
        String id = input.next();

        System.out.print("Select your product name: ");
        String name = input.next();

        System.out.print("Select your product quantity: ");
        int quantity = input.nextInt();

        System.out.print("Select your product price: ");
        double price = input.nextDouble();

        inventory order = new inventory(id, name, quantity, price);
        list.add(order);

        while (true) {

            System.out.println(
                    "Do you want to add, update, or delete a product? (Enter 'add', 'update', 'delete', or 'exit' to quit): ");
            String action = input.next();

            switch (action.toLowerCase()) {
                case "add":
                    order.add();
                    break;

                case "update":

                    System.out.print("Enter new product name: ");
                    String newName = input.next();

                    System.out.print("Enter new product quantity: ");
                    int newQuantity = input.nextInt();

                    System.out.print("Enter new product price: ");
                    double newPrice = input.nextDouble();

                    order.update(newName, newQuantity, newPrice);
                    break;

                case "delete":
                    order.delete();
                    break;

                case "exit":
                    return;

                default:
                    System.out.println("Invalid action. Please enter 'add', 'update', 'delete', or 'exit'.");
                    break;
            }
        }

    }
}